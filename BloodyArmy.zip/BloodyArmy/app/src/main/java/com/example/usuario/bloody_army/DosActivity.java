package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class DosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dos);

        final Button adelante = (Button) findViewById(R.id.botonAdelante);

        adelante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(DosActivity.this, QuizActivity.class);
                startActivity(i);

            }
        });


    }
}

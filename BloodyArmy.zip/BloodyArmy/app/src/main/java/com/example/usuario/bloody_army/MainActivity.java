package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ImageView imagen;
        final Button entrar = (Button) findViewById(R.id.botonLogin);
        final EditText nombre_usuario = (EditText) findViewById(R.id.campo_nombre);
        final EditText contraseña = (EditText) findViewById(R.id.campo_contraseña);
        final String usuario_correcto = "jose";
        final String contraseña_correcta = "a";
        final TextView comprobar = (TextView) findViewById(R.id.aviso);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        imagen = (ImageView) findViewById(R.id.logo);

        imagen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rotarImagen(imagen);
            }
        });


        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(nombre_usuario.getText().toString().equals(usuario_correcto) && contraseña.getText().toString().equals(contraseña_correcta)){
                    comprobar.setText("ACCESO PERMITIDO");
                    comprobar.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                        Intent i = new Intent(MainActivity.this, DosActivity.class);
                        startActivity(i);
                }else {
                    comprobar.setText("ACCESO DENEGADO");
                    comprobar.setTextColor(getResources().getColor(R.color.colorError));
                }

            }
        });

    }

    private void rotarImagen(View view){
        RotateAnimation animation = new RotateAnimation(0, 360,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f);

        animation.setDuration(1000);
        animation.setRepeatCount(1);
        animation.setRepeatMode(Animation.REVERSE);
        view.startAnimation(animation);
    }


}
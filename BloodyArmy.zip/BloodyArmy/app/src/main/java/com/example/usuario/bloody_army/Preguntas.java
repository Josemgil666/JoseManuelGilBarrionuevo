package com.example.usuario.bloody_army;

public class Preguntas {

    public String [] preguntas = {
            "1. ¿Cúal es tu época bélica favorita?",
            "2. ¿Qué arma de la 2ªGM prefieres?",
            "3. ¿Qué ejército estaba mejor armado?",
            "4. ¿Cúal es tu vehiculo preferido?"
    };

    private String [][] opciones = {
            {"1ªGM","2ªGM","VIETNAM","ACTUAL"},
            {"MG42","THOMPSON","MP40","STEN"},
            {"EEUU","URSS","ALEMANIA","FRANCIA"},
            {"SHERMAN","PANZER","JEEP","T30"}
    };

    public String getPregunta(int a) {
        String pregunta = preguntas[a];
        return pregunta;
    }

    public String getRespuesta1(int a) {
        String respuesta = opciones[a][0];
        return respuesta;
    }

    public String getRespuesta2(int a) {
        String respuesta = opciones[a][1];
        return respuesta;
    }

    public String getRespuesta3(int a) {
        String respuesta = opciones[a][2];
        return respuesta;
    }

    public String getRespuesta4(int a) {
        String respuesta = opciones[a][3];
        return respuesta;
    }
}
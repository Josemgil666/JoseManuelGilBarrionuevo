package com.example.jose.troll;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();
            Intent i = new Intent(MainActivity.this,MainActivity.class);
            startActivity(i);
            System.out.println("CREADA");
    }

    protected void onStop() {
        super.onStop();
            Intent i = new Intent(MainActivity.this,MainActivity.class);
            startActivity(i);
            System.out.println("PARADA");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
            Intent i = new Intent(MainActivity.this,MainActivity.class);
            startActivity(i);
            System.out.println("DESTRUIDA");
    }

    @Override
    protected void onPause() {
        super.onPause();
            Intent i = new Intent(MainActivity.this,MainActivity.class);
            startActivity(i);
            System.out.println("PAUSADA");

    }
}

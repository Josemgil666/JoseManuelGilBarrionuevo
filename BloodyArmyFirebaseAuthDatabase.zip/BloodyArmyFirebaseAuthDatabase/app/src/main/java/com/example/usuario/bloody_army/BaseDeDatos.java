package com.example.usuario.bloody_army;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class BaseDeDatos extends android.database.sqlite.SQLiteOpenHelper {

    public BaseDeDatos(Context context) {
        super(context, "base_de_datos", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE usuarios (_id INTEGER PRIMARY KEY AUTOINCREMENT, usuario TEXT, email TEXT, contraseña TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Usuarios");
        db.execSQL("CREATE TABLE usuarios (_id INTEGER PRIMARY KEY AUTOINCREMENT, usuario TEXT, email TEXT, contraseña TEXT)");
    }

    public void guardar(String usuario, String email, String contraseña){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO usuarios VALUES(null, "+"'"+usuario+"', "+"'"+email +"'"+ ", "+"'"+contraseña+"'"+")");
    }

}

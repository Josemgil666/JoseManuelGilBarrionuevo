package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Actividad que se lanzara al hacer clic en el boton de registrarse.
 */

public class RegistrateActivity extends AppCompatActivity implements View.OnClickListener{

    /**
     * El edit text que hacer referencia al email.
     */
    EditText editTextEmail;

    /**
     * El edit text que hacer referencia a la contrasenia.
     */
    EditText editTextPassword;

    /**
     * El boton que se encarga de almacenar los datos a la base de datos.
     */
    Button registrarse;

    /**
     * El escuchador para el estado de la autenticacion.
     */

//  Creamos el escuchador para el estado de la autenticacion.
    FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrate);

        //  OCULTAR LA BARRA SUPERIOR.
        getSupportActionBar().hide();

        registrarse = (Button) findViewById(R.id.botonRegistrate);
        registrarse.setOnClickListener(this);

        editTextEmail = (EditText) findViewById(R.id.campo_email);
        editTextPassword = (EditText) findViewById(R.id.campo_contraseña);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                //  Obtenemos el usuario actual.
                FirebaseUser user = firebaseAuth.getCurrentUser();

                if(user != null){
                    System.out.println("Sesión iniciada con email: "+ user.getEmail());
                }else{
                    System.out.println("Sesión cerrada");
                }
            }
        };
    }

    // Metodo para registrar usuario.
    private void registrar(String email, String pass){
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(RegistrateActivity.this, "Usuario creado correctamente", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(RegistrateActivity.this, DosActivity.class);
                    startActivity(i);
                }else{
                    Toast.makeText(RegistrateActivity.this, "No se ha podido crear", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    //  Metodo para enviar a la base de datos el email y la contrasenia escritos por el usuario.
    public void onClick(View v) {
        String email = editTextEmail.getText().toString();
        String pass = editTextPassword.getText().toString();

        registrar(email, pass);
    }

    @Override
    //  Se ejecutara cuando se inicie la actividad.
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    @Override
    //  Se ejecutara cuando se detenga la actividad.
    protected void onStop() {
        super.onStop();
        if(mAuthListener!=null){
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }
}

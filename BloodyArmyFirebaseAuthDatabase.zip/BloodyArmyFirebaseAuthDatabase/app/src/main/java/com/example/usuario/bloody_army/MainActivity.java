package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button registrate = (Button) findViewById(R.id.botonRegistrate);
        final ImageView imagen;
        final Button entrar = (Button) findViewById(R.id.botonLogin);
        final EditText nombre_usuario = (EditText) findViewById(R.id.campo_email);
        final EditText contraseña = (EditText) findViewById(R.id.campo_contraseña);
        final String usuario_correcto = "jose";
        final String contraseña_correcta = "a";
        final TextView comprobar = (TextView) findViewById(R.id.aviso);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        imagen = (ImageView) findViewById(R.id.logo);

        imagen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rotarImagen(imagen);
            }
        });


        //  Desactivamos el boton "Iniciar Sesión".
        entrar.setEnabled(false);

        //  Asignamos un "Escuchador" al campo de texto "Nombre_usuario".
        nombre_usuario.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(count != 0){
                    entrar.setEnabled(true);
                }else {
                    entrar.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        registrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, RegistrateActivity.class);
                startActivity(i);
            }
        });

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = nombre_usuario.getText().toString();
                String contra = contraseña.getText().toString();

                iniciarSesion(email, contra);

            }
        });

        //  Base de datos con Firebase
        FirebaseDatabase db = FirebaseDatabase.getInstance();

        DatabaseReference ref1 = db.getReference("Usuarios");
        ref1.child("Primer Hijo").setValue("Juan");
        ref1.child("Primera Hija").setValue("Juana");
        ref1.child("Primera Hijastra").setValue("Juanita");

        DatabaseReference ref2 = db.getReference("UsuariosRegistrados");
        ref2.child("Primer Hijo").setValue("Juanillo");

    }

    private void iniciarSesion(String email, String pass){

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this,"Sesión iniciada", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(MainActivity.this, DosActivity.class);
                    startActivity(i);
                }else{
                    Toast.makeText(MainActivity.this,"Imposible iniciar sesión", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void rotarImagen(View view){
        RotateAnimation animation = new RotateAnimation(0, 360,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f);

        animation.setDuration(1000);
        animation.setRepeatCount(1);
        animation.setRepeatMode(Animation.REVERSE);
        view.startAnimation(animation);
    }


}
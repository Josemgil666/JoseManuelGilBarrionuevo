package com.example.usuario.bloody_army;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;

public class QuizActivity extends AppCompatActivity {

    private RoundCornerProgressBar progressButton;

    private Preguntas todasPreguntas = new Preguntas();

    private TextView salir;

    public String respuesta;

    private int contadorPreguntas = 0;

    private int contColor = 0;

    Button respuesta1, respuesta2, respuesta3, respuesta4;

    TextView textoPregunta;

    public int num = 0;

    public String [] respuestas = new String [4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();


        //  ASIGNAR BARRA
        //Toolbar barraApp = (Toolbar) findViewById(R.id.barra);
        //setSupportActionBar(barraApp);


        respuesta1 = (Button) findViewById(R.id.respuesta1);
        respuesta2 = (Button) findViewById(R.id.respuesta2);
        respuesta3 = (Button) findViewById(R.id.respuesta3);
        respuesta4 = (Button) findViewById(R.id.respuesta4);
        textoPregunta = (TextView) findViewById(R.id.pregunta);
        /*salir = (TextView) findViewById(R.id.cerrarSesion);*/

        actualizarPregunta(num);
        num++;

        respuesta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                respuesta = respuesta1.getText().toString();
                respuestas[contadorPreguntas] = respuesta;

                comprobar();
                cambiarProgreso();
            }
        });

        respuesta2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                respuesta = respuesta2.getText().toString();
                respuestas[contadorPreguntas] = respuesta;

                comprobar();
                cambiarProgreso();
            }
        });

        respuesta3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                respuesta = respuesta3.getText().toString();
                respuestas[contadorPreguntas] = respuesta;

                comprobar();
                cambiarProgreso();
            }
        });

        respuesta4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                respuesta = respuesta4.getText().toString();
                respuestas[contadorPreguntas] = respuesta;

                comprobar();
                cambiarProgreso();
            }
        });

        /*salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createDialog();
            }
        });*/


        progressButton = (RoundCornerProgressBar) findViewById(R.id.btn_progress);
        progressButton.setProgressColor(Color.parseColor("#035600"));
        progressButton.setProgressBackgroundColor(Color.parseColor("#FF131313"));
        progressButton.setMax(100);
        progressButton.setProgress(0);

    }

    private void createDialog(){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(this, R.style.estiloDialogo);
        dialogo.setTitle("CERRAR SESIÓN");
        dialogo.setMessage("¿Estás seguro?");
        dialogo.setCancelable(false);

        dialogo.setPositiveButton("Si, estoy seguro", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(QuizActivity.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        dialogo.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog = dialogo.create();
        dialog.show();

    }

    private void actualizarPregunta(int num){
        textoPregunta.setText(todasPreguntas.getPregunta(num));
        respuesta1.setText(todasPreguntas.getRespuesta1(num));
        respuesta2.setText(todasPreguntas.getRespuesta2(num));
        respuesta3.setText(todasPreguntas.getRespuesta3(num));
        respuesta4.setText(todasPreguntas.getRespuesta4(num));
    }

    private void cambiarProgreso(){
        if (contColor==1){
            progressButton.setProgress(25);
        }else if (contColor==2){
            progressButton.setProgress(50);
        }else if (contColor==3){
            progressButton.setProgress(75);
        }else if (contColor==4){
            progressButton.setProgress(100);
        }
    };

    private void comprobar(){
        if (contadorPreguntas == 3){
            contColor++;
            Intent i = new Intent(QuizActivity.this, EnhorabuenaActivity.class);
            i.putExtra("respuestasAnterior",respuestas[0]+respuestas[1]+respuestas[2]+respuestas[3]);
            startActivity(i);
        }else {
            contadorPreguntas++;
            actualizarPregunta(num);
            num++;
            contColor++;
        }
    }
}
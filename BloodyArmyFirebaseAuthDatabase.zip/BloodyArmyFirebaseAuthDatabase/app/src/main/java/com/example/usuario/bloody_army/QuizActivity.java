package com.example.usuario.bloody_army;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Actividad que lanzara las preguntas al usuario.
 */

public class QuizActivity extends AppCompatActivity {

    /**
     * Variable que controlara el acceso a las preguntas de la base de datos.
     */

    //  Variable que controlara el acceso a las preguntas de la base de datos.
    //  ira recorriendo todos los hijos del nodo "Preguntas".
    int total = 1;

    private RoundCornerProgressBar progressButton;

    private Button r1;
    private Button r2;
    private Button r3;
    private Button r4;

    private int contColor = 0;

    private TextView pr;

    /**
     * La referencia a la base de datos.
     */

//  Hacemos la referencia a la base de datos.
    DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        r1 = (Button) findViewById(R.id.respuesta1);
        r2 = (Button) findViewById(R.id.respuesta2);
        r3 = (Button) findViewById(R.id.respuesta3);
        r4 = (Button) findViewById(R.id.respuesta4);

        pr = (TextView) findViewById(R.id.pregunta);

        progressButton = (RoundCornerProgressBar) findViewById(R.id.btn_progress);
        progressButton.setProgressColor(Color.parseColor("#035600"));
        progressButton.setProgressBackgroundColor(Color.parseColor("#FF131313"));
        progressButton.setMax(100);
        progressButton.setProgress(0);

        //  Llamamos al metodo que se encarga de comprobar y actualizar las preguntas.
        actualizarPregunta();

    }

    private void actualizarPregunta(){

        if (total == 5) {
            contColor++;
            Intent i = new Intent(QuizActivity.this, EnhorabuenaActivity.class);
            startActivity(i);

        }else {

            //  Hacemos referencia al nodo "Preguntas" y obtenemos el hijo cuyo valor sea igual a la variable "total",
            //  de este modo conseguiremos que al incrementar la variable "total" accedamos a la siguiente pregunta.
            db = FirebaseDatabase.getInstance().getReference().child("Preguntas").child(String.valueOf(total));

            db.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    // Preguntas2.class convierte un elemento de la base de datos en un objeto de la clase "Preguntas", como si fuese un castin.
                    Preguntas pregunta = dataSnapshot.getValue(Preguntas.class);

                    pr.setText(pregunta.getPregunta());
                    r1.setText(pregunta.getRespuesta1());
                    r2.setText(pregunta.getRespuesta2());
                    r3.setText(pregunta.getRespuesta3());
                    r4.setText(pregunta.getRespuesta4());

                    r1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            contColor++;
                            cambiarProgreso();
                            total++;
                            actualizarPregunta();
                        }
                    });

                    r2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            contColor++;
                            cambiarProgreso();
                            total++;
                            actualizarPregunta();
                        }
                    });

                    r3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            contColor++;
                            cambiarProgreso();
                            total++;
                            actualizarPregunta();
                        }
                    });

                    r4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            contColor++;
                            cambiarProgreso();
                            total++;
                            actualizarPregunta();
                        }
                    });
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    //  Metodo que cambia el proceso de la barra.
    private void cambiarProgreso(){
        if (contColor==1){
            progressButton.setProgress(25);
        }else if (contColor==2){
            progressButton.setProgress(50);
        }else if (contColor==3){
            progressButton.setProgress(75);
        }else if (contColor==4){
            progressButton.setProgress(100);
        }
    };
}
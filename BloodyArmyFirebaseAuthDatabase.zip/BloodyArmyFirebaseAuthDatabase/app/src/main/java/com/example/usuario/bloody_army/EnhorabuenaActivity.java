package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EnhorabuenaActivity extends AppCompatActivity {

    TextView prueba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enhorabuena);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        prueba = (TextView) findViewById(R.id.pruebaLoca);

        recibirDatos();

        Button entrar = (Button) findViewById(R.id.botonEntrar);

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(EnhorabuenaActivity.this, MenuActivity.class);
                startActivity(i);

            }
        });

    }

    public void recibirDatos(){
        Bundle extras = getIntent().getExtras();
        String [] respuestasAnt = new String[1];
        respuestasAnt[0] = extras.getString("respuestasAnterior");
        prueba.setText(respuestasAnt[0]);

    }

    //  MÉTODO QUE CONTROLA EL BOTÓN RETROCEDER EN EL MÓVIL
    //  SI LO DEJAMOS VACÍO ORDENA QUE NO HAGA NADA
    public void onBackPressed(){

    }

}
